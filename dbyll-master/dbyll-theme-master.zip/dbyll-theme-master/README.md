dbyll
=====

2 column stylish theme for jekyll-boostrap-3. Port of original [dbyll theme for Jekyll](http://github.com/dbtek/dbyll).

Install
=======

Inside jekyll-bootstrap root directory, just run
```bash
$ rake theme:install git="https://github.com/jekyll-bootstrap-3/dbyll-theme"
```

**New to Jekyll Bootstrap 3?**  
Visit [Jekyll Bootstrap 3](http://github.com/dbtek/jekyll-bootstrap-3/) for more info.
  
License
=======
[MIT](http://opensource.org/licenses/MIT)

Author
======
İsmail Demirbilek - [@dbtek](http://twitter.com/dbtek)
